
from flask import Flask
from flask_cors import CORS
from modules import init_db

app = Flask(__name__)
CORS(app)

init_db()

# Importing the blueprint after app initialization to avoid circular imports
from routes import api as api_blueprint
app.register_blueprint(api_blueprint, url_prefix='/api')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

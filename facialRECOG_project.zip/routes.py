
from flask import Blueprint, request, jsonify
import modules  # Avoids direct function imports to prevent circular import

api = Blueprint('api', __name__)

@api.route('/employees', methods=['POST'])
def api_add_employee():
    data = request.json
    name = data.get('name')
    face_encoding = data.get('face_encoding')
    if not name or not face_encoding:
        return jsonify({'message': 'Invalid data'}), 400
    modules.add_employee(name, face_encoding)
    return jsonify({'message': 'Employee added successfully'}), 201

@api.route('/employees/<string:name>', methods=['DELETE'])
def api_remove_employee(name):
    modules.remove_employee(name)
    return jsonify({'message': 'Employee removed successfully'}), 200

@api.route('/employees', methods=['GET'])
def api_get_employees():
    employees = modules.get_employees()
    return jsonify(employees), 200

@api.route('/entry', methods=['POST'])
def api_log_entry():
    data = request.json
    name = data.get('name')
    if not name:
        return jsonify({'message': 'Name is required'}), 400
    modules.log_entry(name)
    return jsonify({'message': 'Entry logged successfully'}), 201

@api.route('/entry_logs', methods=['GET'])
def api_get_entry_logs():
    logs = modules.get_entry_logs()
    return jsonify(logs), 200

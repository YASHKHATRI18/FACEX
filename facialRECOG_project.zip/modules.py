
import sqlite3
from datetime import datetime

DATABASE = 'employees.db'

def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS employees (name TEXT PRIMARY KEY, face_encoding TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS entry_logs (name TEXT, entry_time TEXT)''')
    conn.commit()
    conn.close()

def add_employee(name, face_encoding):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('INSERT OR REPLACE INTO employees (name, face_encoding) VALUES (?, ?)', (name, face_encoding))
    conn.commit()
    conn.close()

def remove_employee(name):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM employees WHERE name = ?', (name,))
    conn.commit()
    conn.close()

def get_employees():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT name FROM employees')
    employees = [{'name': row[0]} for row in cursor.fetchall()]
    conn.close()
    return employees

def log_entry(name):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO entry_logs (name, entry_time) VALUES (?, ?)', (name, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def get_entry_logs():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT name, entry_time FROM entry_logs')
    logs = [{'name': row[0], 'entry_time': row[1]} for row in cursor.fetchall()]
    conn.close()
    return logs
